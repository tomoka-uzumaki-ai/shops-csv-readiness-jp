# Free EC local checks / 無料ECローカル確認

Start with index.html. Shipping source is in shipping-rules/. If the fictional sample button is blocked when opened as a local file, import shipping-rules/sample.json with the file picker.

Order replay: Python 3.9+ required. Open order-api-audit/event-replay/ and follow README.md. Original free scanner and six final-state examples are retained unchanged in order-api-audit/.

This is a free, unofficial pilot. Real API/checkout compatibility must be verified separately. No source data is sent. No credentials are used. Real adapter and authorized Sandbox/checkout verification remain separate.

SHA256SUMS lists all packaged files except itself. SOURCE_POINTERS.json records references and limitations. LICENSE.txt applies to new material; original notices remain with original files.
